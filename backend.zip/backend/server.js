const express = require("express");
const mysql = require('mysql2');
const cors = require('cors');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const session = require('express-session');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');


const { check, validationResult } = require('express-validator');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// const users = [
//   { id: 1, name: 'John Doe', email: 'john@example.com' },
//   { id: 2, name: 'Jane Doe', email: 'jane@example.com' }
// ];

// // Route to get all users
// app.get('/users', (req, res) => {
//   res.json(users);
// });

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/'); // Save files in 'uploads' directory
    },
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname);
        cb(null, Date.now() + ext); // Append a timestamp to the file name
    }
});

const upload = multer({ storage: storage });



const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "auth_db",
    port: "3306"
});

// Connect to the database and handle connection errors
db.connect((err) => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to database.');
});
// Endpoint to handle product addition
app.post('/addProduct', upload.single('image'), (req, res) => {
    const { name, price, description } = req.body;
    const image = req.file ? req.file.filename : null;

    // SQL query to insert product details
    const query = 'INSERT INTO products (name, price, description, image) VALUES (?, ?, ?, ?)';
    db.query(query, [name, price, description, image], (err, results) => {
        if (err) {
            console.error('Error adding product:', err);
            return res.status(500).json({ message: 'Error adding product' });
        }
        res.status(200).json({ message: 'Product added successfully' });
    });
});


// Example route for fetching products
app.get('/viewproducts', (req, res) => {
    const query = 'SELECT id, name, price, description, image FROM products'; // Ensure table and column names match your DB schema

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching products:', err);
            return res.status(500).json({ message: 'Error fetching products' });
        }
        res.json(results);
    });
});


// PUT endpoint to update product
app.put('/editproducts/:id', upload.single('image'), (req, res) => {
    const { id } = req.params;
    const { name } = req.body;
    const image = req.file ? req.file.filename : null;
  
    // SQL query to update product details in the database
    let query = 'UPDATE products SET name = ?';
    const values = [name];
  
    if (image) {
      query += ', image = ?';
      values.push(image);
    }
  
    query += ' WHERE id = ?';
    values.push(id);
  
    db.query(query, values, (err, results) => {
      if (err) {
        console.error('Error updating product:', err);
        return res.status(500).json({ message: 'Error updating product' });
      }
  
      if (results.affectedRows > 0) {
        res.status(200).json({ message: 'Product updated successfully' });
      } else {
        res.status(404).json({ message: 'Product not found' });
      }
    });
  });
    
// Example route for fetching products
app.get('/viewallproduct', (req, res) => {
    const query = 'SELECT id, name, price, description, image FROM products'; // Ensure table and column names match your DB schema

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching products:', err);
            return res.status(500).json({ message: 'Error fetching products' });
        }
        res.json(results);
    });
});


// Route to delete a product by ID
app.delete('/viewproducts/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM products WHERE id = ?';

    db.query(query, [id], (err, result) => {
        if (err) {
            console.error('Error deleting product:', err);
            return res.status(500).json({ message: 'Error deleting product' });
        }
        if (result.affectedRows > 0) {
            res.status(200).json({ message: 'Product deleted successfully' });
        } else {
            res.status(404).json({ message: 'Product not found' });
        }
    });
});



// Route to get a single product by ID
app.get('/products/:id', (req, res) => {
    const { id } = req.params;
    const query = 'SELECT * FROM products WHERE id = ?';

    db.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error fetching product:', err);
            return res.status(500).json({ message: 'Error fetching product' });
        }
        if (results.length > 0) {
            res.status(200).json(results[0]);
        } else {
            res.status(404).json({ message: 'Product not found' });
        }
    });
});


app.post('/signup', (req, res) => {
    const sql = "INSERT INTO login (name,email,password) VALUES (?)";
    const values = [
        req.body.name,
        req.body.email,
        req.body.password
    ];
    db.query(sql, [values], (err, data) => {
        if (err) {
            return res.json("Error");
        }
        return res.json(data);
    });
});

app.post('/login', [
    check('email', "Email length should be between 10 to 30 characters").isEmail().isLength({ min: 10, max: 30 }),
    check('password', "Password length should be between 8 to 10 characters").isLength({ min: 8, max: 10 })
], (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.json(errors);
    }

    const sql = "SELECT * FROM login WHERE email = ? AND password = ?";
    db.query(sql, [req.body.email, req.body.password], (err, data) => {
        if (err) {
            return res.json("Error");
        }
        if (data.length > 0) {
            return res.json("Success");
        } else {
            return res.json("Failed");
        }
    });
});


     
// app.get('/user/profile', (req, res) => {
//     // Example: Fetch user profile from database
//     // This is just a placeholder; replace with your actual database logic
//     const userProfile = {
//         name: 'John Doe',
//         email: 'john.doe@example.com',
//         image: 'profile.jpg'
//     };

//     res.json(userProfile);
// });
// Route to authenticate user and create a session

app.use(session({
    secret: 'your_secret_key', // Replace with a strong secret
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false } // Set secure: true if using HTTPS
}));

// app.post('/login', (req, res) => {
//     const { email, password } = req.body;
//     db.query('SELECT * FROM users WHERE email = ?', [email], (err, results) => {
//         if (err) return res.status(500).json({ message: 'Server error' });
//         if (results.length > 0) {
//             const user = results[0];
//             bcrypt.compare(password, user.password, (err, isMatch) => {
//                 if (err) return res.status(500).json({ message: 'Server error' });
//                 if (isMatch) {
//                     req.session.userId = user.id; // Set user ID in session
//                     res.json({ message: 'Logged in successfully' });
//                 } else {
//                     res.status(401).json({ message: 'Invalid credentials' });
//                 }
//             });
//         } else {
//             res.status(404).json({ message: 'User not found' });
//         }
//     });
// });
  
  // Route to get user profile
  app.get('/user/profile', (req, res) => {
    const userId = req.session.userId;
    if (!userId) return res.status(401).json({ message: 'Not authenticated' });

    db.query('SELECT * FROM users WHERE id = ?', [userId], (err, results) => {
        if (err) return res.status(500).json({ message: 'Server error' });
        if (results.length > 0) {
            res.json(results[0]);
        } else {
            res.status(404).json({ message: 'User not found' });
        }
    });
});
  
    
app.listen(8081, () => {
    console.log("Server is listening on port 8081");
});
module.exports = db;
