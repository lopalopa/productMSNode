-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2024 at 07:18 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `auth_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(1, 'lopa', 'dsfdf@gmail.com', 'abcd', '2024-08-31 06:39:39'),
(2, 'lopa1', 'lopa1@gmail.com', 'abcdefgh', '2024-08-31 06:48:16'),
(3, 'lopa3', 'lopa2@gmail.com', 'abcdefgh', '2024-08-31 07:24:47'),
(4, 'csdsdsd', 'sss@jjhh.com', 'abcdefgh', '2024-09-14 16:53:24'),
(5, 'Rashmi', 'lopa10@gmail.com', 'abcdefgh', '2024-09-14 18:22:32'),
(6, 'Rashmi prava mishra', 'lopalopa2007@gmail.com', 'abcdefgh', '2024-09-15 08:09:05'),
(7, 'Rashmi', 'lopalopa27@gmail.com', 'abcdefgh', '2024-11-22 16:06:39'),
(8, 'Rashmi prava mishra1', 'lopalopa20071@gmail.com', 'abcdefgh', '2024-11-22 16:07:28'),
(9, 'Rashmi Mishra', 'lopalopa2@gmail.com', 'abcdefgh', '2024-11-22 16:18:01');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 'newprod123', 2222.00, 'wswdsds', '1726377600970.png', '2024-09-14 18:47:54', '2024-09-15 06:10:17'),
(3, 'miii', 2222.00, 'dsfdfdf', '1726381806257.png', '2024-09-15 06:30:06', '2024-09-15 06:30:06'),
(4, 'new1', 2222.00, 'fffff', '1732291735710.png', '2024-11-22 16:08:55', '2024-11-22 16:08:55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
